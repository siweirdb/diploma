create function delete_expired_codes() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM items_verificationcode WHERE created_at < NOW() - INTERVAL '10 minutes';
    RETURN NULL;
END;
$$;

alter function delete_expired_codes() owner to postgres;

